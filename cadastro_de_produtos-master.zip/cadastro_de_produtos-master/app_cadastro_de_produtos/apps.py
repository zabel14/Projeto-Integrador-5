from django.apps import AppConfig


class AppCadastroDeProdutosConfig(AppConfig):
    name = 'app_cadastro_de_produtos'
